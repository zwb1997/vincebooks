﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Docx2Html
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Entered Docx2Html.exe");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Exiting Docx2Html.exe");
        }
    }
}
