﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.IO
{
    public static class CommonIO1
    {
        public const string CommionIO1Str = Common1.Class1Str + ".Common.IO";

    }
}
