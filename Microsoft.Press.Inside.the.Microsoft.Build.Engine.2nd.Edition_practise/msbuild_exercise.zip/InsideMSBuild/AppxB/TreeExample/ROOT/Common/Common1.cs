﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    public static class Common1
    {
        public const string Class1Str = "Class1";
    }
}
