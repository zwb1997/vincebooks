﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.UI.Editors
{
    public class CommonUIEditors
    {
        public const string CommonUIEditorsStr = Common1.Class1Str + CommonUI1.CommionUI1Str + "CommonUIEditors";
    }
}
