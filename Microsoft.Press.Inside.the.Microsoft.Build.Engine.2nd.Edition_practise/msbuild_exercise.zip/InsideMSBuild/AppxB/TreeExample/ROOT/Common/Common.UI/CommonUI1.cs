﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.UI
{
    public static class CommonUI1
    {
        public const string CommionUI1Str = Common1.Class1Str + ".Common.IO";
    }
}
