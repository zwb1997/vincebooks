The contents of this folder could not be distributed with this package. You can download it at:

http://www.sedodream.com/InsideMSBuild/Contrib.zip

Please email me if you have any issues.

Sayed Ibrahim Hashimi
sayed.hashimi@gmail.com