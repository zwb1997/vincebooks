﻿namespace Examples.Tasks
{
    public static class ExampleValues
    {
        public const string Name = "Example-values";
    }
}
